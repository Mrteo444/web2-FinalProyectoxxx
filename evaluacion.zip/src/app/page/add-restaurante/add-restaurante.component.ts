import { Component } from '@angular/core';

@Component({
  selector: 'app-add-restaurante',
  standalone: true,
  imports: [],
  templateUrl: './add-restaurante.component.html',
  styleUrl: './add-restaurante.component.css'
})
export class AddRestauranteComponent {

}
